var searchData=
[
  ['matrice_10',['matrice',['../structPNM__t.html#a2fd542747d06ef88f5d4a39a1dcb41d1',1,'PNM_t']]],
  ['maximun_5fpixel_11',['maximun_pixel',['../structPNM__t.html#a733988eebffc431486dca886521ab6fb',1,'PNM_t']]]
];
