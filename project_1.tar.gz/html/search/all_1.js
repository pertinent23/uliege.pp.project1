var searchData=
[
  ['nb_5fcolones_2',['nb_colones',['../structPNM__t.html#aaf82d3c41c3ce9570b74bfb88b84f216',1,'PNM_t']]],
  ['nb_5flignes_3',['nb_lignes',['../structPNM__t.html#a2d7b7901587147b4b60f6fc0b1280bb2',1,'PNM_t']]],
  ['nombre_5fmagique_4',['NOMBRE_MAGIQUE',['../classNOMBRE__MAGIQUE.html',1,'']]]
];
