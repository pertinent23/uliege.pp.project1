var structPNM__t =
[
    [ "matrice", "structPNM__t.html#a2fd542747d06ef88f5d4a39a1dcb41d1", null ],
    [ "maximun_pixel", "structPNM__t.html#a733988eebffc431486dca886521ab6fb", null ],
    [ "nb_colones", "structPNM__t.html#aaf82d3c41c3ce9570b74bfb88b84f216", null ],
    [ "nb_lignes", "structPNM__t.html#a2d7b7901587147b4b60f6fc0b1280bb2", null ],
    [ "nombre_magique", "structPNM__t.html#a184001ecc24917a329254560931220cd", null ],
    [ "type", "structPNM__t.html#a2ff952baec6e3a232394bd17fe20e0f0", null ]
];